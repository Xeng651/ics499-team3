<?php
$con = mysqli_connect("localhost", "root", "", "resetpass");

if(mysqli_connect_errno()) {
    echo "Failed connection: " . mysqli_connect_errno();
}
?>