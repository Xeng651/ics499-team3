<?php
include("config.php")

if(!isset($_GET["code"])) {
    exit("Link not working :(")
}

$code = $_GET["code"];

$getEmailQuery = mysqli_query($con, "SELECT email FROM resetpassword WHERE code='$code'");
if(mysqli_num_rows($getEmailQuery) == 0) {
    exit("Link not working :(")
if(isset($_POST["password"])){
    $pw = $_POST["password"];
    $pw = md5($pw);

    $row = mysqli_fetch_array($getEmailQuery);
    $email = $row ["email"];

    $query = mysqli_query($con, "UPDATE users SET passwords='$pw' WHERE email='$email'");

    if($query){
        $query = mysqli_query($con, "DELETE FROM resetpassword WHERE code='$code'");
        exit("Password changed succesfully");
    }
    else {
        exit("Something broke, please wait and try again");
    }

}
?>

<form method="POST">
    <input type="password" name="password" placeholder="New Password">
    <input type="submit" name="submit" value="Update password">
</form>